package tmj.hadyan.moviels.entity;

import android.os.Parcel;
import android.os.Parcelable;
import android.util.Log;

import org.json.JSONObject;

public class Movie implements Parcelable {
    private int id;
    private int id_table;
    private String photo;
    private String name;
    private String description;
    private String date;
    private String genre;
    private String photoPath;
    private String popularity;
    private String score;

    public Movie() {

    }

    public Movie(int id, String date, String name, String description, String score, String popularity, String photoPath) {
        this.id = id;
        this.date = date;
        this.name = name;
        this.description = description;
        this.score = score;
        this.popularity = popularity;
        this.photoPath = photoPath;
    }

    public Movie(JSONObject object) {
        try {
            this.id = object.getInt("id");
            this.date = object.getString("release_date");
            this.name = object.getString("title");
            this.description = object.getString("overview");
            this.photoPath = object.getString("poster_path");
            this.photo =  ("https://image.tmdb.org/t/p/w185" + object.getString("poster_path"));
            this.popularity = object.getString("popularity");
            this.score = object.getString("vote_average");
        } catch (Exception e){
            e.printStackTrace();
            Log.d("Error Data", e.getMessage());
        }
    }

    protected Movie(Parcel in) {
        id = in.readInt();
        id_table = in.readInt();
        photo = in.readString();
        name = in.readString();
        description = in.readString();
        date = in.readString();
        genre = in.readString();
        photoPath = in.readString();
        popularity = in.readString();
        score = in.readString();
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(id);
        dest.writeInt(id_table);
        dest.writeString(photo);
        dest.writeString(name);
        dest.writeString(description);
        dest.writeString(date);
        dest.writeString(genre);
        dest.writeString(photoPath);
        dest.writeString(popularity);
        dest.writeString(score);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<Movie> CREATOR = new Creator<Movie>() {
        @Override
        public Movie createFromParcel(Parcel in) {
            return new Movie(in);
        }

        @Override
        public Movie[] newArray(int size) {
            return new Movie[size];
        }
    };

    public int getId_table() {
        return id_table;
    }

    public void setId_table(int id_table) {
        this.id_table = id_table;
    }

    public String getPhotoPath() {
        return photoPath;
    }

    public void setPhotoPath(String photoPath) {
        this.photoPath = photoPath;
    }

    public String getPhoto() {
        return photo;
    }

    public void setPhoto(String photo) {
        this.photo = photo;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getPopularity() {
        return popularity;
    }

    public void setPopularity(String popularity) {
        this.popularity = popularity;
    }

    public String getScore() {
        return score;
    }

    public void setScore(String score) {
        this.score = score;
    }
}
