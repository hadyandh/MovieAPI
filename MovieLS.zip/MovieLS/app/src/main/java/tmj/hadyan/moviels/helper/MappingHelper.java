package tmj.hadyan.moviels.helper;

import android.database.Cursor;

import java.util.ArrayList;

import tmj.hadyan.moviels.db.DatabaseContract;
import tmj.hadyan.moviels.entity.FavouriteMovie;
import tmj.hadyan.moviels.entity.FavouriteTv;

public class MappingHelper  {
    public static ArrayList<FavouriteMovie> mapCursorToArrayList(Cursor moviesCursor) {
        ArrayList<FavouriteMovie> moviesList = new ArrayList<>();
        while (moviesCursor.moveToNext()) {
            int id = moviesCursor.getInt(moviesCursor.getColumnIndexOrThrow(DatabaseContract.MovieColumns._ID));
            String date = moviesCursor.getString(moviesCursor.getColumnIndexOrThrow(DatabaseContract.MovieColumns.RELEASE));
            String title = moviesCursor.getString(moviesCursor.getColumnIndexOrThrow(DatabaseContract.MovieColumns.TITLE));
            String description = moviesCursor.getString(moviesCursor.getColumnIndexOrThrow(DatabaseContract.MovieColumns.DESCRIPTION));
            String score = moviesCursor.getString(moviesCursor.getColumnIndexOrThrow(DatabaseContract.MovieColumns.SCORE));
            String popular = moviesCursor.getString(moviesCursor.getColumnIndexOrThrow(DatabaseContract.MovieColumns.POPULARITY));
            String photo = moviesCursor.getString(moviesCursor.getColumnIndexOrThrow(DatabaseContract.MovieColumns.PHOTO_PATH));

            moviesList.add(new FavouriteMovie(id, date, title, description, score, popular, photo));
        }
        return moviesList;
    }

    public static ArrayList<FavouriteTv> mapCursorToArrayListTv(Cursor tvCursor) {
        ArrayList<FavouriteTv> tvList = new ArrayList<>();
        while (tvCursor.moveToNext()) {
            int id = tvCursor.getInt(tvCursor.getColumnIndexOrThrow(DatabaseContract.TvColumns._ID));
            String date = tvCursor.getString(tvCursor.getColumnIndexOrThrow(DatabaseContract.TvColumns.RELEASE));
            String title = tvCursor.getString(tvCursor.getColumnIndexOrThrow(DatabaseContract.TvColumns.NAME));
            String description = tvCursor.getString(tvCursor.getColumnIndexOrThrow(DatabaseContract.TvColumns.DESCRIPTION));
            String score = tvCursor.getString(tvCursor.getColumnIndexOrThrow(DatabaseContract.TvColumns.SCORE));
            String popular = tvCursor.getString(tvCursor.getColumnIndexOrThrow(DatabaseContract.TvColumns.POPULARITY));
            String photo = tvCursor.getString(tvCursor.getColumnIndexOrThrow(DatabaseContract.TvColumns.PHOTO_PATH));

            tvList.add(new FavouriteTv(id, date, title, description, score, popular, photo));
        }
        return tvList;
    }
}
