package tmj.hadyan.moviels.fragment;


import android.content.Intent;
import android.database.Cursor;
import android.os.AsyncTask;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import java.lang.ref.WeakReference;
import java.util.ArrayList;

import tmj.hadyan.moviels.DetailFavouriteActivity;
import tmj.hadyan.moviels.MainActivity;
import tmj.hadyan.moviels.R;
import tmj.hadyan.moviels.adapter.CardViewTvAdapter;
import tmj.hadyan.moviels.adapter.MovieFavouriteAdapter;
import tmj.hadyan.moviels.db.MovieHelper;
import tmj.hadyan.moviels.entity.FavouriteMovie;
import tmj.hadyan.moviels.entity.Tv;
import tmj.hadyan.moviels.helper.MappingHelper;

/**
 * A simple {@link Fragment} subclass.
 */
public class MovieFavouriteFragment extends Fragment implements LoadMoviesCallback {
    private ProgressBar progressBar;
    private RecyclerView rvMovie;
    private MovieFavouriteAdapter adapter;
    private MovieHelper movieHelper;
    private static final String EXTRA_STATE = "EXTRA_STATE";


    public MovieFavouriteFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_movie_favourite, container, false);

        progressBar = view.findViewById(R.id.progressBar);
        rvMovie = view.findViewById(R.id.rv_movies);
        rvMovie.setLayoutManager(new LinearLayoutManager(getContext()));
        rvMovie.setHasFixedSize(true);
        adapter = new MovieFavouriteAdapter(getActivity());
        rvMovie.setAdapter(adapter);

        movieHelper = MovieHelper.getInstance(getContext());
        movieHelper.open();

        new LoadMoviesAsync(movieHelper, this).execute();

        /*
        Cek jika savedInstaceState null makan akan melakukan proses asynctask nya
        jika tidak,akan mengambil arraylist nya dari yang sudah di simpan
         */
        if (savedInstanceState == null) {
            new LoadMoviesAsync(movieHelper, this).execute();
        } else {
            ArrayList<FavouriteMovie> list = savedInstanceState.getParcelableArrayList(EXTRA_STATE);
            if (list != null) {
                adapter.setListMovie(list);
            }
        }
        return view;
    }

    @Override
    public void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putParcelableArrayList(EXTRA_STATE, adapter.getListMovie());
    }

    @Override
    public void preExecute() {
        /*
        Callback yang akan dipanggil di onPreExecute Asyntask
        Memunculkan progressbar
        */
        getActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                progressBar.setVisibility(View.VISIBLE);
            }
        });
    }

    @Override
    public void postExecute(ArrayList<FavouriteMovie> movies) {
        /*
        Callback yang akan dipanggil di onPostExture Asynctask
        Menyembunyikan progressbar, kemudian isi adapter dengan data yang ada
         */
        progressBar.setVisibility(View.INVISIBLE);
        if (movies.size() > 0) {
            adapter.setListMovie(movies);
        } else {
            adapter.setListMovie(new ArrayList<FavouriteMovie>());
            showSnackbarMessage(getString(R.string.null_data));
        }
    }

    @Override
    public void onResume(Intent data) {
        super.onResume();
        int position = data.getIntExtra(DetailFavouriteActivity.EXTRA_POSITION, 0);

        adapter.removeItem(position);
        adapter.notifyDataSetChanged();
        showSnackbarMessage("Satu item berhasil dihapus");
    }

    private static class LoadMoviesAsync extends AsyncTask<Void, Void, ArrayList<FavouriteMovie>> {

        private final WeakReference<MovieHelper> weakNoteHelper;
        private final WeakReference<LoadMoviesCallback> weakCallback;

        private LoadMoviesAsync(MovieHelper movieHelper, LoadMoviesCallback callback) {
            weakNoteHelper = new WeakReference<>(movieHelper);
            weakCallback = new WeakReference<>(callback);
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            weakCallback.get().preExecute();
        }

        @Override
        protected ArrayList<FavouriteMovie> doInBackground(Void... voids) {
            Cursor dataCursor = weakNoteHelper.get().queryAll();
            return MappingHelper.mapCursorToArrayList(dataCursor);
        }

        @Override
        protected void onPostExecute(ArrayList<FavouriteMovie> movies) {
            super.onPostExecute(movies);
            weakCallback.get().postExecute(movies);
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == DetailFavouriteActivity.RESULT_DELETE) {
            int position = data.getIntExtra(DetailFavouriteActivity.EXTRA_POSITION, 0);

            adapter.removeItem(position);

            showSnackbarMessage("Satu item berhasil dihapus");
        }

        Log.d("ResultCode", String.valueOf(resultCode));
    }

    @Override
    public void startActivityForResult(Intent intent, int requestCode) {
        super.startActivityForResult(intent, requestCode);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        movieHelper.close();
    }

    public void showSnackbarMessage(String message){
        Snackbar.make(rvMovie, message, Snackbar.LENGTH_SHORT).show();
    }
}

interface LoadMoviesCallback {
    void preExecute();

    void postExecute(ArrayList<FavouriteMovie> movies);

    void onResume(Intent data);
}
