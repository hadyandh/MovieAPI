package tmj.hadyan.moviels.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;

import java.util.ArrayList;

import tmj.hadyan.moviels.entity.Movie;
import tmj.hadyan.moviels.R;

public class CardViewMovieAdapter extends RecyclerView.Adapter<CardViewMovieAdapter.CardViewViewHolder> {
    private ArrayList<Movie> mData;

    private OnItemClickCallback onItemClickCallback;

    public void setOnItemClickCallback(OnItemClickCallback onItemClickCallback) {
        this.onItemClickCallback = onItemClickCallback;
    }

    public CardViewMovieAdapter(ArrayList<Movie> mData) {
        this.mData = mData;
    }

    public void setData(ArrayList<Movie> items) {
        mData.clear();
        mData.addAll(items);
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public CardViewViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int position) {

        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_cardview_movie, viewGroup, false);
        return new CardViewViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final CardViewViewHolder holder, final int position) {
        final Movie movie = mData.get(position);
        Glide.with(holder.itemView.getContext())
                .load(movie.getPhoto())
                .placeholder(R.color.colorSecondary)
                .apply(new RequestOptions().override(350, 550))
                .into(holder.imgPhoto);
        holder.movName.setText(movie.getName());
        holder.movDesc.setText(movie.getDescription());

        holder.btnDetail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onItemClickCallback.onItemClicked(mData.get(holder.getAdapterPosition()));
            }
        });
    }

    @Override
    public int getItemCount() {
        return mData.size();
    }

    public class CardViewViewHolder extends RecyclerView.ViewHolder {
        ImageView imgPhoto;
        TextView movName, movDesc;
        Button btnDetail;
        CardViewViewHolder(@NonNull View itemView) {
            super(itemView);
            imgPhoto = itemView.findViewById(R.id.mov_poster);
            movName = itemView.findViewById(R.id.mov_name);
            movDesc = itemView.findViewById(R.id.mov_desc);
            btnDetail = itemView.findViewById(R.id.btnDetail);
        }
    }

    public interface OnItemClickCallback {
        void onItemClicked(Movie data);
    }
}
