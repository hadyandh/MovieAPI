package tmj.hadyan.moviels.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;

import java.util.ArrayList;

import tmj.hadyan.moviels.R;
import tmj.hadyan.moviels.entity.Tv;

public class CardViewTvAdapter extends RecyclerView.Adapter<CardViewTvAdapter.CardTvHolder> {
    private ArrayList<Tv> tData;

    private OnItemClickCallback onItemClickCallback;

    public void setOnItemClickCallback(OnItemClickCallback onItemClickCallback) {
        this.onItemClickCallback = onItemClickCallback;
    }

    public CardViewTvAdapter(ArrayList<Tv> tData) {
        this.tData = tData;
    }

    public void setData(ArrayList<Tv> items) {
        tData.clear();
        tData.addAll(items);
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public CardTvHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int position) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_cardview_movie, viewGroup, false);
        return new CardTvHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final CardTvHolder holder, final int position) {
        final Tv tv = tData.get(position);
        Glide.with(holder.itemView.getContext())
                .load(tv.getPhoto())
                .placeholder(R.color.colorSecondary)
                .apply(new RequestOptions().override(350, 550))
                .into(holder.imgPhoto);
        holder.movName.setText(tv.getName());
        holder.movDesc.setText(tv.getOverview());

        holder.btnDetail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onItemClickCallback.onItemClicked(tData.get(holder.getAdapterPosition()));
            }
        });
    }

    @Override
    public int getItemCount() {
        return tData.size();
    }

    public class CardTvHolder extends RecyclerView.ViewHolder {
        ImageView imgPhoto;
        TextView movName, movDesc;
        Button btnDetail;

        public CardTvHolder(@NonNull View itemView) {
            super(itemView);
            imgPhoto = itemView.findViewById(R.id.mov_poster);
            movName = itemView.findViewById(R.id.mov_name);
            movDesc = itemView.findViewById(R.id.mov_desc);
            btnDetail = itemView.findViewById(R.id.btnDetail);
        }
    }

    public interface OnItemClickCallback {
        void onItemClicked(Tv data);
    }
}
