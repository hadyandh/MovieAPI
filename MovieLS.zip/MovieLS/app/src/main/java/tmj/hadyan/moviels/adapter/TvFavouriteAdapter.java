package tmj.hadyan.moviels.adapter;

import android.app.Activity;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;

import java.util.ArrayList;

import tmj.hadyan.moviels.CustomOnItemClickListener;
import tmj.hadyan.moviels.DetailFavouriteActivity;
import tmj.hadyan.moviels.R;
import tmj.hadyan.moviels.entity.FavouriteTv;

public class TvFavouriteAdapter extends RecyclerView.Adapter<TvFavouriteAdapter.TvFavHolder> {
    private final ArrayList<FavouriteTv> listTv = new ArrayList<>();
    private final Activity activity;

    public TvFavouriteAdapter(Activity activity) {
        this.activity = activity;
    }

    public ArrayList<FavouriteTv> getListTv() {
        return listTv;
    }

    public void setListTv(ArrayList<FavouriteTv> listTv) {

        if (listTv.size() > 0) {
            this.listTv.clear();
        }
        this.listTv.addAll(listTv);

        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public TvFavHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_cardview_movie, parent, false);
        return new TvFavHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull TvFavHolder holder, int position) {
        Glide.with(holder.itemView.getContext())
                .load(listTv.get(position).getPhotoPath())
                .placeholder(R.color.colorSecondary)
                .apply(new RequestOptions().override(350, 550))
                .into(holder.imgPhoto);
        holder.movName.setText(listTv.get(position).getName());
        holder.movDesc.setText(listTv.get(position).getDescription());

        holder.btnDetail.setOnClickListener(new CustomOnItemClickListener(position, new CustomOnItemClickListener.OnItemClickCallback() {
            @Override
            public void onItemClicked(View view, int position) {
                Intent intent = new Intent(activity, DetailFavouriteActivity.class);
                intent.putExtra(DetailFavouriteActivity.EXTRA_POSITION, position);
                intent.putExtra(DetailFavouriteActivity.EXTRA_TV_FAV, listTv.get(position));
                activity.startActivity(intent);
            }
        }));
    }

    @Override
    public int getItemCount() {
        return listTv.size();
    }

    public class TvFavHolder extends RecyclerView.ViewHolder {
        ImageView imgPhoto;
        TextView movName, movDesc;
        Button btnDetail;

        public TvFavHolder(@NonNull View itemView) {
            super(itemView);
            imgPhoto = itemView.findViewById(R.id.mov_poster);
            movName = itemView.findViewById(R.id.mov_name);
            movDesc = itemView.findViewById(R.id.mov_desc);
            btnDetail = itemView.findViewById(R.id.btnDetail);
        }
    }
}
