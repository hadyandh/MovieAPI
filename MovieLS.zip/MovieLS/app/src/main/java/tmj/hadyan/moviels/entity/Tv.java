package tmj.hadyan.moviels.entity;

import android.os.Parcel;
import android.os.Parcelable;
import android.util.Log;

import org.json.JSONObject;

public class Tv implements Parcelable {
    private int id;
    private String name;
    private String photo;
    private String overview;
    private String date;
    private String genre;
    private String score;
    private String popular;

    public Tv(JSONObject object) {
        try {
            this.id = object.getInt("id");
            this.date = object.getString("first_air_date");
            this.name = object.getString("name");
            this.overview = object.getString("overview");
            this.photo =  ("https://image.tmdb.org/t/p/w500" + object.getString("poster_path"));
            this.score = object.getString("vote_average");
            this.popular = object.getString("popularity");
        } catch (Exception e){
            e.printStackTrace();
            Log.d("Error Data", e.getMessage());
        }
    }

    public Tv() {

    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhoto() {
        return photo;
    }

    public void setPhoto(String photo) {
        this.photo = photo;
    }

    public String getOverview() {
        return overview;
    }

    public void setOverview(String overview) {
        this.overview = overview;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public String getScore() {
        return score;
    }

    public void setScore(String score) {
        this.score = score;
    }

    public String getPopular() {
        return popular;
    }

    public void setPopular(String popular) {
        this.popular = popular;
    }

    protected Tv(Parcel in) {
        id = in.readInt();
        name = in.readString();
        photo = in.readString();
        overview = in.readString();
        date = in.readString();
        genre = in.readString();
        score = in.readString();
        popular = in.readString();
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(id);
        dest.writeString(name);
        dest.writeString(photo);
        dest.writeString(overview);
        dest.writeString(date);
        dest.writeString(genre);
        dest.writeString(score);
        dest.writeString(popular);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<Tv> CREATOR = new Creator<Tv>() {
        @Override
        public Tv createFromParcel(Parcel in) {
            return new Tv(in);
        }

        @Override
        public Tv[] newArray(int size) {
            return new Tv[size];
        }
    };
}
