package tmj.hadyan.moviels.entity;

import android.os.Parcel;
import android.os.Parcelable;

public class FavouriteTv implements Parcelable {
    private int id;
    private String name;
    private String description;
    private String date;
    private String photoPath;
    private String popularity;
    private String score;

    public FavouriteTv(){};

    public FavouriteTv(int id, String date, String name, String description, String score, String popularity, String photoPath) {
        this.id = id;
        this.date = date;
        this.name = name;
        this.description = description;
        this.score = score;
        this.popularity = popularity;
        this.photoPath = photoPath;
    }

    protected FavouriteTv(Parcel in) {
        id = in.readInt();
        name = in.readString();
        description = in.readString();
        date = in.readString();
        photoPath = in.readString();
        popularity = in.readString();
        score = in.readString();
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(id);
        dest.writeString(name);
        dest.writeString(description);
        dest.writeString(date);
        dest.writeString(photoPath);
        dest.writeString(popularity);
        dest.writeString(score);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<FavouriteTv> CREATOR = new Creator<FavouriteTv>() {
        @Override
        public FavouriteTv createFromParcel(Parcel in) {
            return new FavouriteTv(in);
        }

        @Override
        public FavouriteTv[] newArray(int size) {
            return new FavouriteTv[size];
        }
    };

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getPhotoPath() {
        return photoPath;
    }

    public void setPhotoPath(String photoPath) {
        this.photoPath = photoPath;
    }

    public String getPopularity() {
        return popularity;
    }

    public void setPopularity(String popularity) {
        this.popularity = popularity;
    }

    public String getScore() {
        return score;
    }

    public void setScore(String score) {
        this.score = score;
    }
}
