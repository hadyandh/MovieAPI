package tmj.hadyan.moviels;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;

import tmj.hadyan.moviels.db.MovieHelper;
import tmj.hadyan.moviels.db.TvHelper;
import tmj.hadyan.moviels.entity.FavouriteMovie;
import tmj.hadyan.moviels.entity.FavouriteTv;
import tmj.hadyan.moviels.entity.Movie;
import tmj.hadyan.moviels.entity.Tv;

public class DetailActivity extends AppCompatActivity implements View.OnClickListener{

    public static final String EXTRA_TV = "extra_tv";
    public static final String EXTRA_MOVIE = "extra_movie";
    public static final String EXTRA_MOVIE_FAVORITE = "extra_movie_favorite";
    public static final String EXTRA_TV_FAVORITE = "extra_tv_favorite";
    public static final String EXTRA_POSITION = "extra_position";

    public static final int RESULT_ADD = 101;

    private boolean isFavorit = false;
    private boolean isTv = false;
    private int position;
    private MovieHelper movieHelper;
    private FavouriteMovie favouriteMovie;
    private FavouriteTv favouriteTv;
    private TvHelper tvHelper;

    private ProgressBar progressBar;
    private TextView score, sinopsis, date, genre, title;
    private ImageView poster;
    private Button btnFavourite;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        score = findViewById(R.id.mov_score);
        sinopsis = findViewById(R.id.mov_description);
        date = findViewById(R.id.mov_date);
        genre = findViewById(R.id.mov_genre);
        title = findViewById(R.id.mov_name);
        poster = findViewById(R.id.mov_poster);
        btnFavourite = findViewById(R.id.btn_fav);

        progressBar = findViewById(R.id.progressBarDetail);

        showLoading(true);

        Movie movie = getIntent().getParcelableExtra(EXTRA_MOVIE);
        Tv tv = getIntent().getParcelableExtra(EXTRA_TV);

        if (movie != null){
            movieHelper = MovieHelper.getInstance(getApplicationContext());
            movieHelper.open();
            favouriteMovie = getIntent().getParcelableExtra(EXTRA_MOVIE_FAVORITE);

            String url_image = "https://image.tmdb.org/t/p/w154" + movie.getPhotoPath();

            title.setText(movie.getName());
            sinopsis.setText(movie.getDescription());
            score.setText(movie.getScore());
            date.setText(movie.getDate());
            genre.setText(movie.getPopularity());

            Glide.with(this)
                    .load(url_image)
                    .placeholder(R.color.colorSecondary)
                    .apply(new RequestOptions().override(350, 550))
                    .into(poster);

            if (favouriteMovie != null){
                position = getIntent().getIntExtra(EXTRA_POSITION, 0);
                isFavorit = true;
                btnFavourite.setVisibility(View.GONE);

            }else {
                favouriteMovie = new FavouriteMovie();
            }

        }else if (tv != null) {

            tvHelper = TvHelper.getInstance(getApplicationContext());
            tvHelper.open();
            favouriteTv = getIntent().getParcelableExtra(EXTRA_TV_FAVORITE);

            title.setText(tv.getName());
            sinopsis.setText(tv.getOverview());
            date.setText(tv.getDate());
            score.setText(tv.getScore());
            genre.setText(tv.getPopular());

            Glide.with(this)
                    .load(tv.getPhoto())
                    .placeholder(R.color.colorSecondary)
                    .apply(new RequestOptions().override(350, 550))
                    .into(poster);

            if (favouriteTv != null){
                position = getIntent().getIntExtra(EXTRA_POSITION, 0);
                isFavorit = true;
                btnFavourite.setVisibility(View.GONE);

            }else {
                favouriteTv = new FavouriteTv();
            }
        }

        btnFavourite.setOnClickListener(this);

        if(poster!=null) {
            showLoading(false);
        }

        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("");
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }
    }

    @Override
    public boolean onSupportNavigateUp(){
        onBackPressed();
        return true;
    }

    private void showLoading(Boolean state) {
        if (state) {
            progressBar.setVisibility(View.VISIBLE);
        } else {
            progressBar.setVisibility(View.GONE);
        }
    }

    @Override
    public void onClick(View view) {
        if (view.getId() == R.id.btn_fav) {

            Movie movie = getIntent().getParcelableExtra(EXTRA_MOVIE);
            Tv tv = getIntent().getParcelableExtra(EXTRA_TV);

            if (movie != null) {
                String name = title.getText().toString().trim();
                String overview = sinopsis.getText().toString().trim();
                String release = date.getText().toString().trim();
                String vote = score.getText().toString().trim();
                String popularity = genre.getText().toString().trim();
                String url_image = "https://image.tmdb.org/t/p/w154" + movie.getPhotoPath();

                favouriteMovie.setName(name);
                favouriteMovie.setDescription(overview);
                favouriteMovie.setDate(release);
                favouriteMovie.setScore(vote);
                favouriteMovie.setPopularity(popularity);
                favouriteMovie.setPhotoPath(url_image);

                Intent intent = new Intent();
                intent.putExtra(EXTRA_MOVIE_FAVORITE, favouriteMovie);
                intent.putExtra(EXTRA_POSITION, position);

                if (!isFavorit) {

                    long result = movieHelper.insert(favouriteMovie);

                    if (result > 0) {
                        favouriteMovie.setId((int) result);
                        setResult(RESULT_ADD, intent);
                        Toast.makeText(DetailActivity.this, getString(R.string.success), Toast.LENGTH_LONG).show();
                        finish();
                    } else {
                        Toast.makeText(DetailActivity.this, getString(R.string.failed), Toast.LENGTH_LONG).show();
                    }
                }

            } else if (tv != null) {
                String name = title.getText().toString().trim();
                String overview = sinopsis.getText().toString().trim();
                String release = date.getText().toString().trim();
                String vote = score.getText().toString().trim();
                String popularity = genre.getText().toString().trim();
                String url_image = tv.getPhoto();

                favouriteTv.setName(name);
                favouriteTv.setDescription(overview);
                favouriteTv.setDate(release);
                favouriteTv.setScore(vote);
                favouriteTv.setPhotoPath(url_image);
                favouriteTv.setPopularity(popularity);

                Intent intent = new Intent();
                intent.putExtra(EXTRA_TV_FAVORITE, favouriteTv);
                intent.putExtra(EXTRA_POSITION, position);

                if (!isTv) {

                    long result = tvHelper.insert(favouriteTv);

                    if (result > 0) {
                        favouriteTv.setId((int) result);
                        setResult(RESULT_ADD, intent);
                        Toast.makeText(DetailActivity.this, getString(R.string.success), Toast.LENGTH_LONG).show();
                        finish();
                    } else {
                        Toast.makeText(DetailActivity.this, getString(R.string.failed), Toast.LENGTH_LONG).show();
                    }
                }
            }
        }
    }
}
