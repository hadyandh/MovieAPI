package tmj.hadyan.moviels;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;

import java.util.ArrayList;

import tmj.hadyan.moviels.adapter.MovieFavouriteAdapter;
import tmj.hadyan.moviels.db.MovieHelper;
import tmj.hadyan.moviels.db.TvHelper;
import tmj.hadyan.moviels.entity.FavouriteMovie;
import tmj.hadyan.moviels.entity.FavouriteTv;
import tmj.hadyan.moviels.fragment.MovieFavouriteFragment;

public class DetailFavouriteActivity extends AppCompatActivity{
    private final ArrayList<FavouriteMovie> listMovie = new ArrayList<>();

    public static final String EXTRA_TV_FAV = "extra_tv_fav";
    public static final String EXTRA_MOVIE_FAV = "extra_movie_fav";
    public static final String EXTRA_POSITION = "extra_position";
    public static final int RESULT_DELETE = 301;
    private final int ALERT_DIALOG_DELETE = 20;

    private boolean isEdit = false;
    private FavouriteTv tv;
    private FavouriteMovie favouriteMovie;
    private int position;
    private MovieHelper movieHelper;
    private TvHelper tvHelper;
    private MovieFavouriteAdapter adapter;

    private ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_favourite);

        TextView score = findViewById(R.id.mov_score);
        TextView sinopsis = findViewById(R.id.mov_description);
        TextView date = findViewById(R.id.mov_date);
        TextView genre = findViewById(R.id.mov_genre);
        TextView title = findViewById(R.id.mov_name);
        ImageView poster = findViewById(R.id.mov_poster);

        progressBar = findViewById(R.id.progressBarDetail);

        showLoading(true);

        favouriteMovie = getIntent().getParcelableExtra(EXTRA_MOVIE_FAV);
        tv = getIntent().getParcelableExtra(EXTRA_TV_FAV);

        if (favouriteMovie != null) {
            movieHelper = MovieHelper.getInstance(getApplicationContext());
            position = getIntent().getIntExtra(EXTRA_POSITION, 0);

            title.setText(favouriteMovie.getName());
            sinopsis.setText(favouriteMovie.getDescription());
            score.setText(favouriteMovie.getScore());
            date.setText(favouriteMovie.getDate());
            genre.setText(favouriteMovie.getPopularity());

            Glide.with(this)
                    .load(favouriteMovie.getPhotoPath())
                    .placeholder(R.color.colorSecondary)
                    .apply(new RequestOptions().override(350, 550))
                    .into(poster);
            isEdit = true;

        } else if (tv != null) {
            tvHelper = TvHelper.getInstance(getApplicationContext());

            title.setText(tv.getName());
            sinopsis.setText(tv.getDescription());
            date.setText(tv.getDate());
            score.setText(tv.getScore());
            genre.setText(tv.getPopularity());

            Glide.with(this)
                    .load(tv.getPhotoPath())
                    .placeholder(R.color.colorSecondary)
                    .apply(new RequestOptions().override(350, 550))
                    .into(poster);

            isEdit = true;
        }

        if(poster!=null) {
            showLoading(false);
        }

        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("");
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }
    }

    @Override
    public boolean onSupportNavigateUp(){
        onBackPressed();
        return true;
    }

    private void showLoading(Boolean state) {
        if (state) {
            progressBar.setVisibility(View.VISIBLE);
        } else {
            progressBar.setVisibility(View.GONE);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.details_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.menu_delete) {
            showAlertDialog(ALERT_DIALOG_DELETE);
        }
        return super.onOptionsItemSelected(item);
    }

    private void showAlertDialog(int type) {
        String dialogTitle, dialogMessage;

        dialogMessage = getString(R.string.dialog_message);
        dialogTitle = getString(R.string.dialog_title);

        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
        alertDialogBuilder.setTitle(dialogTitle);
        alertDialogBuilder
                .setMessage(dialogMessage)
                .setCancelable(false)
                .setPositiveButton(getString(R.string.yes), new DialogInterface.OnClickListener() {

                    public void onClick(DialogInterface dialog, int id) {

                        if (favouriteMovie != null){
                            long resultMovie = movieHelper.deleteById(String.valueOf(favouriteMovie.getId()));
                            if (resultMovie > 0) {
                                Intent intent = new Intent();
                                intent.putExtra(EXTRA_POSITION, position);
                                setResult(RESULT_DELETE, intent);
                                finish();
                            } else {
                                Toast.makeText(DetailFavouriteActivity.this, getString(R.string.failed_del), Toast.LENGTH_SHORT).show();
                            }

                        } else if (tv != null) {
                            long resultTv = tvHelper.deleteById(String.valueOf(tv.getId()));

                            if (resultTv > 0) {
//                                adapter.removeItem(position);

//                                int position = data.getIntExtra(DetailFavouriteActivity.EXTRA_POSITION, 0);
//                                listMovie.remove(position);
//                                adapter.notifyItemRemoved(position);
//                                adapter.notifyItemRangeChanged(position, listMovie.size());

                                Intent intent = new Intent();
                                intent.putExtra(EXTRA_POSITION, position);
                                setResult(RESULT_DELETE, intent);
                                adapter.notifyItemRemoved(position);
                                finish();
                            } else {
                                Toast.makeText(DetailFavouriteActivity.this, getString(R.string.failed_del), Toast.LENGTH_SHORT).show();
                            }
                        }
                    }
                })

                .setNegativeButton(getString(R.string.no), new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                });

        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();
    }

}
