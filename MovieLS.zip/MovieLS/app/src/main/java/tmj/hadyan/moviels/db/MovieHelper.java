package tmj.hadyan.moviels.db;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;

import tmj.hadyan.moviels.entity.FavouriteMovie;

import static tmj.hadyan.moviels.db.DatabaseContract.MovieColumns.DESCRIPTION;
import static tmj.hadyan.moviels.db.DatabaseContract.MovieColumns.ID_MOVIE;
import static tmj.hadyan.moviels.db.DatabaseContract.MovieColumns.PHOTO_PATH;
import static tmj.hadyan.moviels.db.DatabaseContract.MovieColumns.POPULARITY;
import static tmj.hadyan.moviels.db.DatabaseContract.MovieColumns.RELEASE;
import static tmj.hadyan.moviels.db.DatabaseContract.MovieColumns.SCORE;
import static tmj.hadyan.moviels.db.DatabaseContract.MovieColumns.TITLE;
import static tmj.hadyan.moviels.db.DatabaseContract.MovieColumns._ID;
import static tmj.hadyan.moviels.db.DatabaseContract.TABLE_NAME_MOVIE;

public class MovieHelper {
    private static final String DATABASE_TABLE = TABLE_NAME_MOVIE;
    private static DatabaseHelper dataBaseHelper;
    private static MovieHelper INSTANCE;
    private static SQLiteDatabase database;

    private MovieHelper(Context context) {
        dataBaseHelper = new DatabaseHelper(context);
    }

    public static MovieHelper getInstance(Context context) {
        if (INSTANCE == null) {
            synchronized (SQLiteOpenHelper.class) {
                if (INSTANCE == null) {
                    INSTANCE = new MovieHelper(context);
                }
            }
        }
        return INSTANCE;
    }

    public void open() throws SQLException {
        database = dataBaseHelper.getWritableDatabase();
    }

    public void close() {
        dataBaseHelper.close();
        if (database.isOpen())
            database.close();
    }

    public Cursor queryAll() {
        return database.query(
                DATABASE_TABLE,
                null,
                null,
                null,
                null,
                null,
                _ID + " ASC");
    }

    public long insert(FavouriteMovie favouriteMovie) {
        ContentValues args = new ContentValues();
        args.put(RELEASE, favouriteMovie.getDate());
        args.put(TITLE, favouriteMovie.getName());
        args.put(DESCRIPTION, favouriteMovie.getDescription());
        args.put(SCORE, favouriteMovie.getScore());
        args.put(POPULARITY, favouriteMovie.getPopularity());
        args.put(PHOTO_PATH, favouriteMovie.getPhotoPath());
        Log.d("INSERT", args.toString());
        return database.insert(DATABASE_TABLE, null, args);
    }

    public int deleteById(String id) {
        return database.delete(DATABASE_TABLE, _ID + " = ?", new String[]{id});
    }
}
