package tmj.hadyan.moviels.db;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;

import tmj.hadyan.moviels.entity.FavouriteMovie;
import tmj.hadyan.moviels.entity.FavouriteTv;

import static android.provider.BaseColumns._ID;
import static tmj.hadyan.moviels.db.DatabaseContract.TvColumns.DESCRIPTION;
import static tmj.hadyan.moviels.db.DatabaseContract.TvColumns.PHOTO_PATH;
import static tmj.hadyan.moviels.db.DatabaseContract.TvColumns.POPULARITY;
import static tmj.hadyan.moviels.db.DatabaseContract.TvColumns.RELEASE;
import static tmj.hadyan.moviels.db.DatabaseContract.TvColumns.SCORE;
import static tmj.hadyan.moviels.db.DatabaseContract.TvColumns.NAME;
import static tmj.hadyan.moviels.db.DatabaseContract.TABLE_NAME_TV;

public class TvHelper {
    private static final String DATABASE_TABLE = TABLE_NAME_TV;
    private static DatabaseHelper dataBaseHelper;
    private static TvHelper INSTANCE;
    private static SQLiteDatabase database;

    private TvHelper(Context context) {
        dataBaseHelper = new DatabaseHelper(context);
    }

    public static TvHelper getInstance(Context context) {
        if (INSTANCE == null) {
            synchronized (SQLiteOpenHelper.class) {
                if (INSTANCE == null) {
                    INSTANCE = new TvHelper(context);
                }
            }
        }
        return INSTANCE;
    }

    public void open() throws SQLException {
        database = dataBaseHelper.getWritableDatabase();
    }

    public void close() {
        dataBaseHelper.close();
        if (database.isOpen())
            database.close();
    }

    public Cursor queryAll() {
        return database.query(
                DATABASE_TABLE,
                null,
                null,
                null,
                null,
                null,
                _ID + " ASC");
    }

    public Cursor queryById(String id) {
        return database.query(DATABASE_TABLE,
                null,
                _ID + " = ?",
                new String[]{id},
                null,
                null,
                null,
                null);
    }

    public ArrayList<FavouriteTv> getAll() {
        ArrayList<FavouriteTv> arrayList = new ArrayList<>();
        Cursor cursor = database.query(DATABASE_TABLE, null,
                null,
                null,
                null,
                null,
                _ID + "ASC",
                null
        );
        cursor.moveToFirst();
        FavouriteTv favouriteTv;

        if (cursor.getCount() > 0) {
            do {
                favouriteTv = new FavouriteTv();
                favouriteTv.setId(cursor.getInt(cursor.getColumnIndexOrThrow(_ID)));
                favouriteTv.setDate(cursor.getString(cursor.getColumnIndexOrThrow(RELEASE)));
                favouriteTv.setName(cursor.getString(cursor.getColumnIndexOrThrow(NAME)));
                favouriteTv.setDescription(cursor.getString(cursor.getColumnIndexOrThrow(DESCRIPTION)));
                favouriteTv.setScore(cursor.getString(cursor.getColumnIndexOrThrow(SCORE)));
                favouriteTv.setPopularity(cursor.getString(cursor.getColumnIndexOrThrow(POPULARITY)));
                favouriteTv.setPhotoPath(cursor.getString(cursor.getColumnIndexOrThrow(PHOTO_PATH)));
                arrayList.add(favouriteTv);
                cursor.moveToNext();
            } while (!cursor.isAfterLast());
        }
        cursor.close();
        return arrayList;
    }

    public long insert(FavouriteTv favouriteTv) {
        ContentValues args = new ContentValues();
        args.put(RELEASE, favouriteTv.getDate());
        args.put(NAME, favouriteTv.getName());
        args.put(DESCRIPTION, favouriteTv.getDescription());
        args.put(SCORE, favouriteTv.getScore());
        args.put(POPULARITY, favouriteTv.getPopularity());
        args.put(PHOTO_PATH, favouriteTv.getPhotoPath());
        Log.d("INSERT", args.toString());
        return database.insert(DATABASE_TABLE, null, args);
    }

    public int update(String id, ContentValues values) {
        return database.update(DATABASE_TABLE, values, _ID + " = ?", new String[]{id});
    }

    public int deleteById(String id) {
        return database.delete(DATABASE_TABLE, _ID + " = ?", new String[]{id});
    }
}
